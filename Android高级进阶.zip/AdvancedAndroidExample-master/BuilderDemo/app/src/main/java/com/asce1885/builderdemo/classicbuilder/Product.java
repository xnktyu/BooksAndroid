package com.asce1885.builderdemo.classicbuilder;

/**
 * Created by guhaoxin on 16/12/25.
 */
public class Product {

    private String partOne;

    private String partTwo;

    public String getPartOne() {
        return partOne;
    }

    public void setPartOne(String partOne) {
        this.partOne = partOne;
    }

    public String getPartTwo() {
        return partTwo;
    }

    public void setPartTwo(String partTwo) {
        this.partTwo = partTwo;
    }
}
