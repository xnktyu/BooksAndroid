package com.asce1885.builderdemo.classicbuilder;

/**
 * Created by guhaoxin on 16/12/25.
 */

public interface Builder {

    public void buildPartOne();

    public void buildPartTwo();

    public Product getProduct();
}
