# AdvancedAndroidExample

1. [《第1章：Android触摸事件传递机制》](https://github.com/ASCE1885/AdvancedAndroidExample/tree/master/ViewDemo)
2. [《第5章》：Percent Support Library 使用详解](https://github.com/ASCE1885/AdvancedAndroidExample/tree/master/PercentSupportDemo)
3. [《第6章》：Design Support Library 使用详解](https://github.com/ASCE1885/AdvancedAndroidExample/tree/master/cheesesquare)
4. [《第10章》：Builder模式详解](https://github.com/ASCE1885/AdvancedAndroidExample/tree/master/BuilderDemo)
5. [《第12章》：ANR产生的原因及其定位分析](https://github.com/ASCE1885/AdvancedAndroidExample/tree/master/ANRDemo)
